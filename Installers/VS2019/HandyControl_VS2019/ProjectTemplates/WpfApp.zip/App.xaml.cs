﻿namespace WpfApp1
{
    public partial class App
    {
    }
}
