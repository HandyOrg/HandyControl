﻿namespace $safeprojectname$
{
    public partial class App
    {
    }
}
